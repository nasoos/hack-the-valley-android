
var table = module.exports = require('azure-mobile-apps').table();

table.columns = {
    "id": "string",
    "createdAt": "date",
    "updatedAt": "date",
    "itemName": "string",
    "price": "number"
};

table.access = 'authenticated';

table.dynamicSchema = false;

table.read(function (context) {
    context.query.where({ userId: context.user.Id });
    return context.execute();
});

// CREATE - add or overwrite the userId based on the authenticated user
table.insert(function (context) {
    context.item.userId = context.user.id;
    return context.execute();
});

// UPDATE - only allow updating of record belong to the authenticated user
table.update(function (context) {
    context.query.where({ userId: context.user.id });
    return context.execute();
});

// DELETE - only allow deletion of records belong to the authenticated uer
table.delete(function (context) {
    context.query.where({ userId: context.user.id });
    return context.execute();
});

table.delete.access = 'disabled';
