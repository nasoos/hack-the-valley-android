// ----------------------------------------------------------------------------
// Copyright (c) 2015 Microsoft Corporation. All rights reserved.
// ----------------------------------------------------------------------------

///<reference path="typings/azure-mobile-apps/azure-mobile-apps.d.ts" />
